# Mbongo Business — Advanced Production Edition

Cloud-ready business management system for customers, jobs, quotations, receipts, finance, users and audit history.

## Included now
- Supabase authentication and role-based workspace
- Customer management + search
- Job/activity creation with browser GPS capture when permission is granted
- Quotations with automatic quotation numbers
- Receipts that also create an income transaction
- Income and expense recording
- Dashboard metrics
- User/role view and audit log
- Responsive mobile/PWA foundation
- Print support for document screens
- PostgreSQL schema + RLS foundation

## Setup
1. Create a Supabase project.
2. Run `schema.sql` in Supabase SQL Editor.
3. Run `storage.sql` if you want cloud photos/files.
4. Create an `.env` from `.env.example` and add the Supabase URL and anon key.
5. Install dependencies: `npm install`
6. Start locally: `npm run dev`
7. Deploy the built app to Vercel, Netlify, Cloudflare Pages, or another static host.

## Important
This package is a real deployable application, but it is not automatically connected to your cloud account. You must supply your own Supabase project credentials and deploy it. Do not put service-role keys in the browser.
