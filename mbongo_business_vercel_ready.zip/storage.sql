-- Run after the schema if you want job photos/receipts stored in Supabase Storage.
insert into storage.buckets (id,name,public) values ('business-files','business-files',false)
on conflict (id) do nothing;

create policy "authenticated users can read business files"
on storage.objects for select to authenticated
using (bucket_id='business-files');

create policy "authenticated users can upload business files"
on storage.objects for insert to authenticated
with check (bucket_id='business-files');
