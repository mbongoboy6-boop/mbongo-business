-- MBONGO BUSINESS: production-oriented Supabase schema
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  phone text,
  role text not null default 'worker' check (role in ('admin','manager','accountant','supervisor','worker','viewer')),
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  email text,
  address text,
  latitude numeric,
  longitude numeric,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists activities (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references customers(id) on delete set null,
  service text not null,
  description text,
  assigned_user uuid references profiles(id) on delete set null,
  status text not null default 'Assigned',
  progress integer not null default 0 check(progress between 0 and 100),
  location_text text,
  latitude numeric,
  longitude numeric,
  budget numeric not null default 0,
  start_date date,
  completion_date date,
  created_at timestamptz not null default now()
);

create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  activity_id uuid references activities(id) on delete set null,
  customer_id uuid references customers(id) on delete set null,
  type text not null check(type in ('Income','Expense')),
  category text,
  amount numeric not null check(amount >= 0),
  payment_method text,
  reference text,
  status text not null default 'Pending',
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists quotations (
  id uuid primary key default gen_random_uuid(),
  number text unique not null,
  customer_id uuid references customers(id) on delete set null,
  activity_id uuid references activities(id) on delete set null,
  description text,
  quantity numeric not null default 1,
  unit_price numeric not null default 0,
  discount numeric not null default 0,
  total numeric not null default 0,
  valid_until date,
  status text not null default 'Draft',
  terms text,
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists receipts (
  id uuid primary key default gen_random_uuid(),
  number text unique not null,
  customer_id uuid references customers(id) on delete set null,
  activity_id uuid references activities(id) on delete set null,
  amount numeric not null check(amount >= 0),
  payment_method text,
  reference text,
  description text,
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists activity_updates (
  id uuid primary key default gen_random_uuid(),
  activity_id uuid not null references activities(id) on delete cascade,
  user_id uuid references profiles(id) on delete set null,
  progress integer check(progress between 0 and 100),
  status text,
  note text,
  latitude numeric,
  longitude numeric,
  created_at timestamptz not null default now()
);

create table if not exists audit_log (
  id bigint generated always as identity primary key,
  user_id uuid references profiles(id) on delete set null,
  action text not null,
  record_type text,
  record_id text,
  metadata jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.current_role()
returns text language sql stable security definer set search_path=public
as $$ select role from public.profiles where id=auth.uid() $$;

create or replace function public.is_admin_or_manager()
returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(public.current_role() in ('admin','manager'),false) $$;

alter table profiles enable row level security;
alter table customers enable row level security;
alter table activities enable row level security;
alter table transactions enable row level security;
alter table quotations enable row level security;
alter table receipts enable row level security;
alter table activity_updates enable row level security;
alter table audit_log enable row level security;

create policy "profiles read authenticated" on profiles for select to authenticated using (true);
create policy "admins manage profiles" on profiles for all to authenticated using (public.current_role()='admin') with check (public.current_role()='admin');

create policy "business users read customers" on customers for select to authenticated using (true);
create policy "authorized users write customers" on customers for insert to authenticated with check (public.current_role() in ('admin','manager','supervisor'));
create policy "authorized users update customers" on customers for update to authenticated using (public.current_role() in ('admin','manager','supervisor')) with check (public.current_role() in ('admin','manager','supervisor'));

create policy "users read activities" on activities for select to authenticated using (true);
create policy "managers create activities" on activities for insert to authenticated with check (public.current_role() in ('admin','manager','supervisor'));
create policy "assigned or managers update activities" on activities for update to authenticated using (public.current_role() in ('admin','manager','supervisor') or assigned_user=auth.uid()) with check (public.current_role() in ('admin','manager','supervisor') or assigned_user=auth.uid());

create policy "authorized read transactions" on transactions for select to authenticated using (public.current_role() in ('admin','manager','accountant') or created_by=auth.uid());
create policy "authorized create transactions" on transactions for insert to authenticated with check (public.current_role() in ('admin','manager','accountant','supervisor','worker'));
create policy "managers update transactions" on transactions for update to authenticated using (public.current_role() in ('admin','manager','accountant')) with check (public.current_role() in ('admin','manager','accountant'));

create policy "authorized read quotations" on quotations for select to authenticated using (true);
create policy "authorized create quotations" on quotations for insert to authenticated with check (public.current_role() in ('admin','manager','accountant'));
create policy "authorized update quotations" on quotations for update to authenticated using (public.current_role() in ('admin','manager','accountant')) with check (public.current_role() in ('admin','manager','accountant'));

create policy "authorized read receipts" on receipts for select to authenticated using (public.current_role() in ('admin','manager','accountant'));
create policy "authorized create receipts" on receipts for insert to authenticated with check (public.current_role() in ('admin','manager','accountant'));
create policy "authorized update receipts" on receipts for update to authenticated using (public.current_role() in ('admin','manager','accountant')) with check (public.current_role() in ('admin','manager','accountant'));

create policy "read activity updates" on activity_updates for select to authenticated using (true);
create policy "workers add updates" on activity_updates for insert to authenticated with check (user_id=auth.uid() or public.current_role() in ('admin','manager','supervisor'));

create policy "audit admins read" on audit_log for select to authenticated using (public.current_role() in ('admin','manager'));
create policy "audit authenticated insert" on audit_log for insert to authenticated with check (user_id=auth.uid());

-- New users receive a profile. Default role is worker; promote the first/admin user manually.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.profiles(id,name) values(new.id,coalesce(new.raw_user_meta_data->>'name','')); return new; end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
